package com.nebula.launcher

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.nebula.launcher.auth.XboxAuthManager
import com.nebula.launcher.versions.ApkVersionManager
import java.io.File

object Config {
    /** Вставьте сюда Application (client) ID из Azure — нужен только для входа через Microsoft. */
    const val AZURE_CLIENT_ID = "PUT_YOUR_AZURE_CLIENT_ID_HERE"
}

class AppState(val ctx: Context) {
    val versions = ApkVersionManager(ctx)
    val auth = XboxAuthManager(ctx, Config.AZURE_CLIENT_ID)
    var list by mutableStateOf(versions.list())
    var selectedId by mutableStateOf<String?>(list.firstOrNull()?.id)
    val selected get() = list.firstOrNull { it.id == selectedId } ?: list.firstOrNull()
    val comMojang: File get() = File(ctx.filesDir, "games/com.mojang").apply { mkdirs() }
    fun refresh() { list = versions.list(); if (selected == null) selectedId = list.firstOrNull()?.id }
}
