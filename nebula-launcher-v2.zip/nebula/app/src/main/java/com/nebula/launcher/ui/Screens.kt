package com.nebula.launcher.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.nebula.launcher.AppState
import com.nebula.launcher.Config
import com.nebula.launcher.ai.*
import com.nebula.launcher.auth.Account
import com.nebula.launcher.auth.MicrosoftLoginWebView
import com.nebula.launcher.versions.ApkVersionManager
import com.nebula.launcher.versions.ImportResult
import kotlinx.coroutines.launch
import java.io.File

@Composable
private fun Page(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp), content = content)

@Composable
private fun Card(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxWidth().glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)

// ------------------------------------------------------------------ HOME
@Composable
fun HomeScreen(s: AppState) {
    val ctx = LocalContext.current
    val account by s.auth.account.collectAsState()
    val scan = remember { s.versions.scanInstalled() }
    Page {
        Text("Nebula Launcher", style = MaterialTheme.typography.headlineMedium)
        Column(Modifier.fillMaxWidth().glass(glow = true).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(if (scan.installed) "Найден установленный Minecraft ${scan.versionName}" else "Установленный Minecraft не найден",
                style = MaterialTheme.typography.titleMedium)
            Text("Рекомендация: Official Xbox License — лучший и самый стабильный выбор 2026.", color = Nebula.TextLo)
        }
        Card {
            Text("Игрок", color = Nebula.TextLo)
            Text(when (val a = account) {
                is Account.Xbox -> "Xbox: ${a.gamertag}"
                is Account.Offline -> "Офлайн: ${a.name}"
                Account.SignedOut -> "Не выбран (вкладка «Аккаунт»)"
            }, style = MaterialTheme.typography.titleMedium)
        }
        Card {
            Text("Версия игры", color = Nebula.TextLo)
            val v = s.selected
            Text(v?.let { "Minecraft ${it.versionName} (${it.abi})" } ?: "Добавьте APK во вкладке «Версии»",
                style = MaterialTheme.typography.titleMedium)
            Button(enabled = v != null, onClick = {
                s.versions.launch(v!!)
                    .onSuccess { Toast.makeText(ctx, "Библиотеки игры загружены", Toast.LENGTH_LONG).show() }
                    .onFailure { Toast.makeText(ctx, "Ошибка: ${it.message}", Toast.LENGTH_LONG).show() }
            }) { Text("ИГРАТЬ") }
        }
    }
}

// ------------------------------------------------------------------ VERSIONS
@Composable
fun VersionSettingsScreen(s: AppState) {
    val scope = rememberCoroutineScope()
    var progress by remember { mutableStateOf<Float?>(null) }
    var stage by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            error = null; progress = 0f
            when (val r = s.versions.importApk(uri) { p, t -> progress = p; stage = t }) {
                is ImportResult.Success -> { s.refresh(); s.selectedId = r.version.id }
                is ImportResult.Failure -> error = r.reason
            }
            progress = null
        }
    }
    Page {
        Text("Настройки версий", style = MaterialTheme.typography.headlineMedium)
        Card {
            Text("Выберите скачанный APK Minecraft Bedrock — лаунчер сам распакует библиотеки и добавит версию.", color = Nebula.TextLo)
            Button(enabled = progress == null, onClick = { picker.launch(arrayOf("*/*")) }) { Text("Выбрать APK") }
            progress?.let { LinearProgressIndicator(progress = { it }, Modifier.fillMaxWidth()); Text(stage, color = Nebula.TextLo) }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
        s.list.forEach { v ->
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = s.selected?.id == v.id, onClick = { s.selectedId = v.id })
                    Column(Modifier.weight(1f)) {
                        Text("Minecraft ${v.versionName}", style = MaterialTheme.typography.titleMedium)
                        Text("${v.abi} • code ${v.versionCode}", color = Nebula.TextLo)
                    }
                    IconButton(onClick = { s.versions.delete(v.id); s.refresh() }) { Icon(Icons.Default.Delete, "Удалить") }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ AI STUDIO
@Composable
fun AiStudioScreen(s: AppState) {
    val scope = rememberCoroutineScope()
    var key by rememberSaveable { mutableStateOf("") }
    var prompt by rememberSaveable { mutableStateOf("") }
    var kind by remember { mutableStateOf(PackKind.BEHAVIOR) }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var pack by remember { mutableStateOf<GeneratedPack?>(null) }
    val ctx = LocalContext.current
    Page {
        Text("AI студия", style = MaterialTheme.typography.headlineMedium)
        Card {
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("API-ключ Anthropic") },
                singleLine = true, visualTransformation = PasswordVisualTransformation())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(kind == PackKind.BEHAVIOR, { kind = PackKind.BEHAVIOR }, { Text("Мод (Behavior)") })
                FilterChip(kind == PackKind.RESOURCE, { kind = PackKind.RESOURCE }, { Text("Ресурспак") })
            }
            OutlinedTextField(prompt, { prompt = it }, Modifier.fillMaxWidth(), minLines = 3,
                label = { Text("Например: меч, который бьёт молнией") })
            Button(enabled = !busy && key.isNotBlank() && prompt.isNotBlank(), onClick = {
                scope.launch {
                    busy = true; status = "Генерация…"; pack = null
                    AiModGenerator(LlmConfig(apiKey = key.trim())).generate(prompt, kind)
                        .onSuccess { pack = it; status = "Готово: ${it.name} (${it.files.size} файлов)" }
                        .onFailure { status = "Ошибка: ${it.message}" }
                    busy = false
                }
            }) { Text(if (busy) "Подождите…" else "Создать") }
            status?.let { Text(it, color = Nebula.TextLo) }
        }
        pack?.let { p ->
            Card {
                Text(p.name, style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        val dir = AiModGenerator(LlmConfig("")).inject(p, s.comMojang)
                        status = "Установлено: ${dir.path}"
                    }) { Text("В игру") }
                    OutlinedButton(onClick = {
                        val f = File(ctx.getExternalFilesDir(null), "${p.folderName}.mcpack")
                        AiModGenerator(LlmConfig("")).toMcpack(p, f); status = "Сохранено: ${f.path}"
                    }) { Text(".mcpack") }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ ACCOUNT
@Composable
fun AccountScreen(s: AppState) {
    val scope = rememberCoroutineScope()
    val account by s.auth.account.collectAsState()
    var name by rememberSaveable { mutableStateOf("Steve") }
    var authUrl by remember { mutableStateOf<String?>(null) }
    var msg by remember { mutableStateOf<String?>(null) }
    var handled by remember { mutableStateOf(false) }

    authUrl?.let { url ->
        Column(Modifier.fillMaxSize()) {
            TextButton(onClick = { authUrl = null }) { Text("← Назад") }
            MicrosoftLoginWebView(url, onRedirect = { redirect ->
                if (!handled) { handled = true; authUrl = null
                    scope.launch { runCatching { s.auth.completeSignIn(redirect) }.onFailure { msg = it.message } } }
            }, modifier = Modifier.fillMaxSize())
        }
        return
    }
    Page {
        Text("Аккаунт", style = MaterialTheme.typography.headlineMedium)
        Card {
            Text("Сейчас: " + when (val a = account) {
                is Account.Xbox -> "Xbox — ${a.gamertag}"
                is Account.Offline -> "Офлайн — ${a.name}"
                Account.SignedOut -> "не выбран"
            })
            if (account !is Account.SignedOut) OutlinedButton(onClick = { s.auth.signOut() }) { Text("Выйти") }
        }
        Card {
            Text("Офлайн-режим", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Ник") })
            Button(onClick = { s.auth.signInOffline(name) }) { Text("Играть офлайн") }
        }
        Card {
            Text("Xbox / Microsoft", style = MaterialTheme.typography.titleMedium)
            val ready = Config.AZURE_CLIENT_ID != "PUT_YOUR_AZURE_CLIENT_ID_HERE"
            if (!ready) Text("Сначала впишите Azure client ID в AppState.kt", color = Nebula.TextLo)
            Button(enabled = ready, onClick = { handled = false; msg = null; authUrl = s.auth.buildAuthUrl() }) { Text("Войти через Microsoft") }
            msg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}
