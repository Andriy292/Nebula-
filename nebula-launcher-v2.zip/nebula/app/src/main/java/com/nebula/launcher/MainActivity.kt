package com.nebula.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nebula.launcher.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { DarkBlueTheme { App() } }
    }
}

private data class Tab(val route: String, val title: String, val icon: ImageVector)

@Composable
fun App() {
    val ctx = LocalContext.current
    val state = remember { AppState(ctx.applicationContext) }
    val nav = rememberNavController()
    val tabs = listOf(
        Tab("home", "Главная", Icons.Default.Home),
        Tab("controls", "Управление", Icons.Default.Gamepad),
        Tab("versions", "Версии", Icons.Default.Memory),
        Tab("ai", "AI", Icons.Default.AutoAwesome),
        Tab("account", "Аккаунт", Icons.Default.Person)
    )
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            NavigationBar(containerColor = Nebula.Navy.copy(alpha = 0.92f)) {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = current == t.route,
                        onClick = { nav.navigate(t.route) { launchSingleTop = true; popUpTo("home") } },
                        icon = { Icon(t.icon, t.title) },
                        label = { Text(t.title, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Nebula.AccentGlow, selectedTextColor = Nebula.AccentGlow,
                            indicatorColor = Nebula.NavyHigh, unselectedIconColor = Nebula.TextLo, unselectedTextColor = Nebula.TextLo)
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { HomeScreen(state) }
            composable("controls") { ControlSettingsScreen() }
            composable("versions") { VersionSettingsScreen(state) }
            composable("ai") { AiStudioScreen(state) }
            composable("account") { AccountScreen(state) }
        }
    }
}
