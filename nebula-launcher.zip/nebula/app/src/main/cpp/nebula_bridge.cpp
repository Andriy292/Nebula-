// Shared state between Kotlin UI and the in-game hooks.
// Hooks read these atomics every frame; Kotlin writes them via JNI. Lock-free by design.
#include <jni.h>
#include <atomic>
#include <dlfcn.h>
#include <android/log.h>
#define TAG "NebulaBridge"

namespace nebula {
std::atomic<float> fov{70.f};
std::atomic<bool>  freelook{false}, freecam{false}, stretch43{false};
std::atomic<float> freelookYaw{0.f}, freelookPitch{0.f};
void* gameHandle = nullptr;

// Version-specific: resolve camera/projection functions by byte-pattern signature scan of the
// mapped libminecraftpe.so (offsets change every release), then install an inline hook
// (Dobby / xHook / ShadowHook) that overrides FOV, camera rotation and the projection matrix
// using the atomics above. Keep one signature table per registered version id.
bool installHooks(void* /*handle*/, const char* /*versionId*/) {
    __android_log_print(ANDROID_LOG_INFO, TAG, "hook table not provided for this version");
    return false;
}
}  // namespace nebula

extern "C" {
JNIEXPORT jboolean JNICALL Java_com_nebula_launcher_native_NativeBridge_nativeLoadGame(
        JNIEnv* env, jobject, jstring path, jstring versionId) {
    const char* p = env->GetStringUTFChars(path, nullptr);
    nebula::gameHandle = dlopen(p, RTLD_NOW | RTLD_GLOBAL);
    env->ReleaseStringUTFChars(path, p);
    if (!nebula::gameHandle) { __android_log_print(ANDROID_LOG_ERROR, TAG, "dlopen: %s", dlerror()); return JNI_FALSE; }
    const char* v = env->GetStringUTFChars(versionId, nullptr);
    nebula::installHooks(nebula::gameHandle, v);
    env->ReleaseStringUTFChars(versionId, v);
    return JNI_TRUE;
}
JNIEXPORT void JNICALL Java_com_nebula_launcher_native_NativeBridge_setFov(JNIEnv*, jobject, jfloat f) { nebula::fov = f; }
JNIEXPORT void JNICALL Java_com_nebula_launcher_native_NativeBridge_setFreelook(JNIEnv*, jobject, jboolean b) { nebula::freelook = b; }
JNIEXPORT void JNICALL Java_com_nebula_launcher_native_NativeBridge_setFreecam(JNIEnv*, jobject, jboolean b) { nebula::freecam = b; }
JNIEXPORT void JNICALL Java_com_nebula_launcher_native_NativeBridge_setStretch43(JNIEnv*, jobject, jboolean b) { nebula::stretch43 = b; }
}
