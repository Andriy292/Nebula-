package com.nebula.launcher.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nebula.launcher.native.NativeBridge
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID
import kotlin.math.roundToInt

// ----------------------------------------------------------------- MODEL
@Serializable
enum class ControlAction(val label: String, val toggle: Boolean) {
    ZOOM("Zoom", false), FREELOOK("Freelook", true), FREECAM("Freecam", true), ASPECT_4_3("4:3", true),
    JUMP("Jump", false), SNEAK("Sneak", true), ATTACK("Attack", false), USE("Use", false), CUSTOM_KEY("Key", false)
}

@Serializable
data class ControlButton(
    val id: String = UUID.randomUUID().toString(),
    val action: ControlAction,
    val label: String = action.label,
    val x: Float = 0.5f,          // normalized 0..1 of the screen — layout survives any resolution
    val y: Float = 0.5f,
    val sizeDp: Float = 56f,
    val keyCode: Int = 0,         // used by CUSTOM_KEY
    val opacity: Float = 0.85f
)

class ControlLayoutRepository(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("controls", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }
    fun load(): List<ControlButton> = prefs.getString("layout", null)
        ?.let { runCatching { json.decodeFromString<List<ControlButton>>(it) }.getOrNull() } ?: defaults()
    fun save(list: List<ControlButton>) = prefs.edit().putString("layout", json.encodeToString(list)).apply()
    private fun defaults() = listOf(
        ControlButton(action = ControlAction.ZOOM, x = 0.08f, y = 0.20f),
        ControlButton(action = ControlAction.FREELOOK, x = 0.08f, y = 0.38f),
        ControlButton(action = ControlAction.FREECAM, x = 0.08f, y = 0.56f),
        ControlButton(action = ControlAction.ASPECT_4_3, x = 0.92f, y = 0.20f)
    )
}

// ----------------------------------------------------------------- VIEWMODEL
class ControlsViewModel(app: android.app.Application) : androidx.lifecycle.AndroidViewModel(app) {
    private val repo = ControlLayoutRepository(app)
    private val _buttons = MutableStateFlow(repo.load())
    val buttons = _buttons.asStateFlow()
    private val _selected = MutableStateFlow<String?>(null)
    val selected = _selected.asStateFlow()

    init { // debounce disk writes so dragging never blocks the UI thread
        viewModelScope.launch { _buttons.debounce(400).collect { repo.save(it) } }
    }

    fun select(id: String?) { _selected.value = id }
    fun add(action: ControlAction) = _buttons.update { it + ControlButton(action = action) }
    fun remove(id: String) { _buttons.update { l -> l.filterNot { it.id == id } }; _selected.value = null }
    fun move(id: String, dx: Float, dy: Float) = patch(id) { it.copy(x = (it.x + dx).coerceIn(0.02f, 0.98f), y = (it.y + dy).coerceIn(0.04f, 0.96f)) }
    fun resize(id: String, dp: Float) = patch(id) { it.copy(sizeDp = dp) }
    fun rebind(id: String, a: ControlAction) = patch(id) { it.copy(action = a, label = a.label) }
    fun opacity(id: String, v: Float) = patch(id) { it.copy(opacity = v) }
    private fun patch(id: String, f: (ControlButton) -> ControlButton) =
        _buttons.update { l -> l.map { if (it.id == id) f(it) else it } }
}

// ----------------------------------------------------------------- RUNTIME DISPATCH
/** Smooth FOV: eases toward target each frame (exponential smoothing, frame-rate independent). */
object ZoomController {
    private const val BASE = 70f; private const val ZOOMED = 20f
    @Volatile private var target = BASE
    private var current = BASE
    suspend fun run(scope: kotlinx.coroutines.CoroutineScope) {
        var last = 0L
        while (scope.isActive) androidx.compose.runtime.withFrameNanos { now ->
            val dt = if (last == 0L) 0.016f else (now - last) / 1e9f; last = now
            current += (target - current) * (1f - kotlin.math.exp(-12f * dt))
            if (kotlin.math.abs(target - current) > 0.01f) NativeBridge.setFov(current)
        }
    }
    fun set(zoomed: Boolean) { target = if (zoomed) ZOOMED else BASE }
}

object ControlDispatcher {
    private val toggles = mutableMapOf<ControlAction, Boolean>()
    fun press(a: ControlAction) {
        when (a) {
            ControlAction.ZOOM -> ZoomController.set(true)
            ControlAction.FREELOOK -> flip(a) { NativeBridge.setFreelook(it) }
            ControlAction.FREECAM -> flip(a) { NativeBridge.setFreecam(it) }
            ControlAction.ASPECT_4_3 -> flip(a) { NativeBridge.setStretch43(it) }
            else -> Unit // movement/combat keys are forwarded through the game's InputQueue in the overlay host
        }
    }
    fun release(a: ControlAction) { if (a == ControlAction.ZOOM) ZoomController.set(false) }
    fun isOn(a: ControlAction) = toggles[a] == true
    private inline fun flip(a: ControlAction, apply: (Boolean) -> Unit) { val v = !(toggles[a] ?: false); toggles[a] = v; apply(v) }
}

// ----------------------------------------------------------------- SCREEN (EDITOR)
@Composable
fun ControlSettingsScreen(vm: ControlsViewModel = viewModel()) {
    val buttons by vm.buttons.collectAsState()
    val selectedId by vm.selected.collectAsState()
    val selected = buttons.firstOrNull { it.id == selectedId }
    var canvas by remember { mutableStateOf(androidx.compose.ui.unit.IntSize(1, 1)) }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Настройки управления", style = MaterialTheme.typography.headlineMedium)
        Text("Drag to move • tap to select • edit below", color = Nebula.TextLo, style = MaterialTheme.typography.bodyMedium)

        // Preview canvas — 20:9 like a phone in landscape
        Box(
            Modifier.fillMaxWidth().aspectRatio(20f / 9f).glass(24.dp, glow = true)
                .onSizeChanged { canvas = it }
                .pointerInput(Unit) { detectTapGestures { vm.select(null) } }
        ) {
            buttons.forEach { b -> EditableButton(b, b.id == selectedId, canvas, vm) }
        }

        // Add palette
        Text("Add button", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ControlAction.entries.forEach { a ->
                AssistChip(onClick = { vm.add(a) }, label = { Text(a.label) }, leadingIcon = { Icon(Icons.Default.Add, null, Modifier.size(16.dp)) })
            }
        }

        // Inspector
        AnimatedInspector(selected, vm)
    }
}

@Composable
private fun EditableButton(b: ControlButton, isSel: Boolean, canvas: androidx.compose.ui.unit.IntSize, vm: ControlsViewModel) {
    val w by rememberUpdatedState(canvas.width.coerceAtLeast(1)); val h by rememberUpdatedState(canvas.height.coerceAtLeast(1))
    val density = LocalContext.current.resources.displayMetrics.density
    val px = b.sizeDp * density
    Box(
        Modifier
            .offset { IntOffset((b.x * w - px / 2).roundToInt(), (b.y * h - px / 2).roundToInt()) }
            .size(b.sizeDp.dp)
            .shadow(if (isSel) 14.dp else 4.dp, CircleShape, ambientColor = Nebula.AccentGlow, spotColor = Nebula.AccentGlow)
            .background(Nebula.NavyHigh.copy(alpha = b.opacity), CircleShape)
            .border(if (isSel) 2.dp else 1.dp, if (isSel) Nebula.AccentGlow else Nebula.GlassStroke, CircleShape)
            .pointerInput(b.id) {
                detectDragGestures(onDragStart = { vm.select(b.id) }) { change, drag ->
                    change.consume(); vm.move(b.id, drag.x / w, drag.y / h)
                }
            }
            .pointerInput(b.id) { detectTapGestures { vm.select(b.id) } },
        contentAlignment = Alignment.Center
    ) { Text(b.label, fontSize = (b.sizeDp / 4.6f).sp, color = Nebula.TextHi, textAlign = TextAlign.Center, maxLines = 1) }
}

@Composable
private fun AnimatedInspector(sel: ControlButton?, vm: ControlsViewModel) {
    androidx.compose.animation.AnimatedVisibility(sel != null) {
        if (sel == null) return@AnimatedVisibility
        Column(Modifier.fillMaxWidth().glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Edit: ${sel.label}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = { vm.remove(sel.id) }) { Icon(Icons.Default.Delete, "Delete", tint = MaterialTheme.colorScheme.error) }
            }
            Text("Size ${sel.sizeDp.roundToInt()}dp", color = Nebula.TextLo)
            Slider(sel.sizeDp, { vm.resize(sel.id, it) }, valueRange = 36f..120f)
            Text("Opacity ${(sel.opacity * 100).roundToInt()}%", color = Nebula.TextLo)
            Slider(sel.opacity, { vm.opacity(sel.id, it) }, valueRange = 0.2f..1f)
            Text("Bind to", color = Nebula.TextLo)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ControlAction.entries.forEach { a ->
                    FilterChip(selected = sel.action == a, onClick = { vm.rebind(sel.id, a) }, label = { Text(a.label) })
                }
            }
        }
    }
}

// ----------------------------------------------------------------- IN-GAME OVERLAY
@Composable
fun ControlsOverlay(vm: ControlsViewModel = viewModel()) {
    val buttons by vm.buttons.collectAsState()
    var size by remember { mutableStateOf(androidx.compose.ui.unit.IntSize(1, 1)) }
    val density = LocalContext.current.resources.displayMetrics.density
    LaunchedEffect(Unit) { ZoomController.run(this) }
    Box(Modifier.fillMaxSize().onSizeChanged { size = it }) {
        buttons.forEach { b ->
            val px = b.sizeDp * density
            var active by remember(b.id) { mutableStateOf(false) }
            Box(
                Modifier
                    .offset { IntOffset((b.x * size.width - px / 2).roundToInt(), (b.y * size.height - px / 2).roundToInt()) }
                    .size(b.sizeDp.dp)
                    .background((if (active || ControlDispatcher.isOn(b.action)) Nebula.Accent else Nebula.NavyHigh).copy(alpha = b.opacity), CircleShape)
                    .border(1.dp, Nebula.GlassStroke, CircleShape)
                    .pointerInput(b.id) {
                        detectTapGestures(onPress = {
                            active = true; ControlDispatcher.press(b.action)
                            tryAwaitRelease(); active = false; ControlDispatcher.release(b.action)
                        })
                    },
                contentAlignment = Alignment.Center
            ) { Text(b.label, fontSize = (b.sizeDp / 4.6f).sp, color = Color.White, maxLines = 1) }
        }
    }
}
