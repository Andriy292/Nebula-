package com.nebula.launcher.native

object NativeBridge {
    init { System.loadLibrary("nebula_bridge") }
    external fun nativeLoadGame(path: String, versionId: String): Boolean
    external fun setFov(fov: Float)
    external fun setFreelook(on: Boolean)
    external fun setFreecam(on: Boolean)
    external fun setStretch43(on: Boolean)
}
