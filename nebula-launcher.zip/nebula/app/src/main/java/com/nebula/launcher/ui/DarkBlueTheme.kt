package com.nebula.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Nebula {
    val Midnight = Color(0xFF050B1F)
    val Navy = Color(0xFF0A1633)
    val NavyHigh = Color(0xFF12224A)
    val Accent = Color(0xFF3D8BFF)
    val AccentGlow = Color(0xFF5CE1FF)
    val Violet = Color(0xFF7B5CFF)
    val GlassFill = Color(0x1AFFFFFF)
    val GlassStroke = Color(0x33A9C7FF)
    val TextHi = Color(0xFFEAF1FF)
    val TextLo = Color(0xFF8FA3CC)
}

private val Scheme = darkColorScheme(
    primary = Nebula.Accent, onPrimary = Color.White,
    secondary = Nebula.AccentGlow, tertiary = Nebula.Violet,
    background = Nebula.Midnight, onBackground = Nebula.TextHi,
    surface = Nebula.Navy, onSurface = Nebula.TextHi,
    surfaceVariant = Nebula.NavyHigh, onSurfaceVariant = Nebula.TextLo,
    outline = Nebula.GlassStroke, error = Color(0xFFFF6B8B)
)

private val Type = Typography(
    headlineMedium = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.3).sp),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.4.sp)
)

@Composable
fun DarkBlueTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = Type) {
        NebulaBackground { content() }
    }
}

/** Animated aurora backdrop: two slowly drifting radial glows over a navy vertical gradient. */
@Composable
fun NebulaBackground(content: @Composable () -> Unit) {
    val t = rememberInfiniteTransition(label = "aurora")
    val drift by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "d")
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Nebula.Midnight, Nebula.Navy)))
            .drawBehind {
                drawCircle(
                    Brush.radialGradient(listOf(Nebula.Accent.copy(0.28f), Color.Transparent),
                        center = Offset(size.width * (0.15f + 0.3f * drift), size.height * 0.1f), radius = size.width * 0.8f),
                    radius = size.width * 0.8f, center = Offset(size.width * (0.15f + 0.3f * drift), size.height * 0.1f))
                drawCircle(
                    Brush.radialGradient(listOf(Nebula.Violet.copy(0.20f), Color.Transparent),
                        center = Offset(size.width * (0.9f - 0.3f * drift), size.height * 0.85f), radius = size.width * 0.9f),
                    radius = size.width * 0.9f, center = Offset(size.width * (0.9f - 0.3f * drift), size.height * 0.85f))
            }
    ) { content() }
}

/**
 * Glassmorphism surface. Real backdrop blur is expensive on mid-range GPUs, so we fake it with
 * a translucent gradient fill + hairline gradient border — cheap and looks the same over the aurora.
 */
fun Modifier.glass(corner: Dp = 20.dp, glow: Boolean = false): Modifier = this
    .clip(RoundedCornerShape(corner))
    .background(Brush.linearGradient(listOf(Color(0x24FFFFFF), Color(0x0AFFFFFF))))
    .border(1.dp, Brush.linearGradient(listOf(Nebula.GlassStroke, Color(0x0DFFFFFF))), RoundedCornerShape(corner))
    .then(if (glow) Modifier.drawBehind {
        drawRoundRect(Nebula.Accent.copy(0.18f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(corner.toPx()))
    } else Modifier)

@Composable
fun glowBrush() = Brush.horizontalGradient(listOf(Nebula.Accent, Nebula.AccentGlow))
