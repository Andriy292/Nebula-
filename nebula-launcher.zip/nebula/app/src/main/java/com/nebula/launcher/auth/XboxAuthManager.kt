package com.nebula.launcher.auth

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID

sealed interface Account {
    data object SignedOut : Account
    data class Offline(val name: String, val uuid: String) : Account
    data class Xbox(val gamertag: String, val xuid: String, val avatarUrl: String?) : Account
}

class XboxAuthException(msg: String) : Exception(msg)

/**
 * Microsoft OAuth2 (PKCE, public client) -> Xbox Live user token -> XSTS -> profile.
 * Register an Azure app (personal accounts, "Mobile and desktop" public client) and pass its client id.
 * NOTE: this signs the user into the LAUNCHER. The game's in-game Xbox sign-in (multiplayer, Realms)
 * is still performed by Minecraft itself.
 */
class XboxAuthManager(
    ctx: Context,
    private val clientId: String,
    private val http: OkHttpClient = OkHttpClient()
) {
    companion object {
        const val REDIRECT = "https://login.live.com/oauth20_desktop.srf"
        private const val SCOPE = "XboxLive.signin XboxLive.offline_access"
        private const val AUTHORIZE = "https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize"
        private const val TOKEN = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token"
        private const val XBL = "https://user.auth.xboxlive.com/user/authenticate"
        private const val XSTS = "https://xsts.auth.xboxlive.com/xsts/authorize"
        private const val PROFILE = "https://profile.xboxlive.com/users/me/profile/settings?settings=Gamertag,GameDisplayPicRaw"
        private val JSON_MT = "application/json".toMediaType()
    }

    private val prefs = EncryptedSharedPreferences.create(
        ctx, "auth_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    private val _account = MutableStateFlow<Account>(restore())
    val account: StateFlow<Account> = _account

    private var verifier: String = ""
    private var state: String = ""

    // ------------------------------------------------------------- offline / guest
    fun signInOffline(name: String): Account.Offline {
        val clean = name.trim().replace(Regex("[^A-Za-z0-9_ ]"), "").take(16).ifBlank { "Steve" }
        val uuid = UUID.nameUUIDFromBytes("OfflinePlayer:$clean".toByteArray()).toString()
        return Account.Offline(clean, uuid).also {
            prefs.edit().putString("kind", "offline").putString("name", clean).putString("uuid", uuid).apply(); _account.value = it
        }
    }

    // ------------------------------------------------------------- step 1: auth URL (+PKCE)
    fun buildAuthUrl(): String {
        val rnd = SecureRandom()
        verifier = ByteArray(48).also(rnd::nextBytes).b64url()
        state = ByteArray(16).also(rnd::nextBytes).b64url()
        val challenge = MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray()).b64url()
        return android.net.Uri.parse(AUTHORIZE).buildUpon()
            .appendQueryParameter("client_id", clientId).appendQueryParameter("response_type", "code")
            .appendQueryParameter("redirect_uri", REDIRECT).appendQueryParameter("scope", SCOPE)
            .appendQueryParameter("code_challenge", challenge).appendQueryParameter("code_challenge_method", "S256")
            .appendQueryParameter("state", state).appendQueryParameter("prompt", "select_account").build().toString()
    }

    /** Called with the redirect URL captured by the WebView. */
    suspend fun completeSignIn(redirectUrl: String): Account.Xbox = withContext(Dispatchers.IO) {
        val uri = android.net.Uri.parse(redirectUrl)
        uri.getQueryParameter("error")?.let { throw XboxAuthException("Microsoft: ${uri.getQueryParameter("error_description") ?: it}") }
        if (uri.getQueryParameter("state") != state) throw XboxAuthException("State mismatch (possible CSRF)")
        val code = uri.getQueryParameter("code") ?: throw XboxAuthException("No authorization code")
        val tokens = tokenRequest(FormBody.Builder().add("grant_type", "authorization_code").add("code", code)
            .add("redirect_uri", REDIRECT).add("code_verifier", verifier))
        finishChain(tokens)
    }

    // ------------------------------------------------------------- silent refresh at launcher start
    suspend fun refresh(): Account = withContext(Dispatchers.IO) {
        val rt = prefs.getString("refresh", null) ?: return@withContext _account.value
        runCatching { finishChain(tokenRequest(FormBody.Builder().add("grant_type", "refresh_token").add("refresh_token", rt))) }
            .getOrElse { _account.value }
    }

    fun signOut() { prefs.edit().clear().apply(); CookieManager.getInstance().removeAllCookies(null); _account.value = Account.SignedOut }

    // ------------------------------------------------------------- internals
    private fun tokenRequest(form: FormBody.Builder): JsonObject {
        val req = Request.Builder().url(TOKEN).post(form.add("client_id", clientId).add("scope", SCOPE).build()).build()
        return http.newCall(req).execute().use { r ->
            val o = Json.parseToJsonElement(r.body!!.string()).jsonObject
            if (!r.isSuccessful) throw XboxAuthException(o["error_description"]?.jsonPrimitive?.content ?: "Token request failed")
            o
        }
    }

    private fun finishChain(tok: JsonObject): Account.Xbox {
        val access = tok["access_token"]!!.jsonPrimitive.content
        tok["refresh_token"]?.jsonPrimitive?.content?.let { prefs.edit().putString("refresh", it).apply() }

        val xbl = postJson(XBL, buildJsonObject {
            putJsonObject("Properties") { put("AuthMethod", "RPS"); put("SiteName", "user.auth.xboxlive.com"); put("RpsTicket", "d=$access") }
            put("RelyingParty", "http://auth.xboxlive.com"); put("TokenType", "JWT")
        })
        val xblToken = xbl["Token"]!!.jsonPrimitive.content
        val uhs = xbl["DisplayClaims"]!!.jsonObject["xui"]!!.jsonArray[0].jsonObject["uhs"]!!.jsonPrimitive.content

        val xsts = postJson(XSTS, buildJsonObject {
            putJsonObject("Properties") { put("SandboxId", "RETAIL"); putJsonArray("UserTokens") { add(xblToken) } }
            put("RelyingParty", "http://xboxlive.com"); put("TokenType", "JWT")
        })
        val xstsToken = xsts["Token"]!!.jsonPrimitive.content

        val req = Request.Builder().url(PROFILE)
            .header("Authorization", "XBL3.0 x=$uhs;$xstsToken").header("x-xbl-contract-version", "2").build()
        val profile = http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw XboxAuthException("Profile HTTP ${r.code}")
            Json.parseToJsonElement(r.body!!.string()).jsonObject
        }
        val user = profile["profileUsers"]!!.jsonArray[0].jsonObject
        val settings = user["settings"]!!.jsonArray.associate { it.jsonObject["id"]!!.jsonPrimitive.content to it.jsonObject["value"]!!.jsonPrimitive.content }
        val acc = Account.Xbox(settings["Gamertag"] ?: "Player", user["id"]!!.jsonPrimitive.content, settings["GameDisplayPicRaw"])
        prefs.edit().putString("kind", "xbox").putString("gt", acc.gamertag).putString("xuid", acc.xuid).putString("pic", acc.avatarUrl).apply()
        _account.value = acc
        return acc
    }

    private fun postJson(url: String, body: JsonObject): JsonObject {
        val req = Request.Builder().url(url).header("Accept", "application/json").header("x-xbl-contract-version", "1")
            .post(body.toString().toRequestBody(JSON_MT)).build()
        return http.newCall(req).execute().use { r ->
            val txt = r.body!!.string()
            if (!r.isSuccessful) {
                val xerr = runCatching { Json.parseToJsonElement(txt).jsonObject["XErr"]?.jsonPrimitive?.long }.getOrNull()
                throw XboxAuthException(when (xerr) {
                    2148916233 -> "This Microsoft account has no Xbox profile. Create one at xbox.com first."
                    2148916238 -> "Child account: add it to a Microsoft Family before signing in."
                    2148916235 -> "Xbox Live is not available in your region."
                    else -> "Xbox auth failed (HTTP ${r.code})"
                })
            }
            Json.parseToJsonElement(txt).jsonObject
        }
    }

    private fun restore(): Account = when (prefs.getString("kind", null)) {
        "offline" -> Account.Offline(prefs.getString("name", "Steve")!!, prefs.getString("uuid", "")!!)
        "xbox" -> Account.Xbox(prefs.getString("gt", "Player")!!, prefs.getString("xuid", "")!!, prefs.getString("pic", null))
        else -> Account.SignedOut
    }

    private fun ByteArray.b64url() = Base64.encodeToString(this, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
}

/** Drop-in login screen body. */
@Composable
fun MicrosoftLoginWebView(authUrl: String, onRedirect: (String) -> Unit, modifier: Modifier = Modifier) {
    AndroidView(modifier = modifier, factory = { ctx ->
        WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            webViewClient = object : WebViewClient() {
                private fun intercept(url: String) = url.startsWith(XboxAuthManager.REDIRECT).also { if (it) onRedirect(url) }
                override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = intercept(r.url.toString())
                override fun onPageStarted(v: WebView, url: String, f: Bitmap?) { if (intercept(url)) v.stopLoading() }
            }
            loadUrl(authUrl)
        }
    })
}
