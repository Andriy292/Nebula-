package com.nebula.launcher.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

enum class PackKind { BEHAVIOR, RESOURCE }

data class LlmConfig(
    val apiKey: String,                                   // user-supplied, kept in EncryptedSharedPreferences
    val endpoint: String = "https://api.anthropic.com/v1/messages",
    val model: String = "claude-sonnet-4-6",
    val scriptApiVersion: String = "1.16.0"               // @minecraft/server version — match the target game build
)

@Serializable private data class PackFile(val path: String, val content: String)
@Serializable private data class LlmPack(val name: String, val description: String = "", val files: List<PackFile>)

data class GeneratedPack(val kind: PackKind, val name: String, val packId: String, val version: List<Int>, val files: Map<String, ByteArray>) {
    val folderName get() = name.replace(Regex("[^A-Za-z0-9_-]"), "_")
}

class AiModGenerator(
    private val config: LlmConfig,
    private val http: OkHttpClient = OkHttpClient.Builder().readTimeout(120, TimeUnit.SECONDS).build()
) {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private fun systemPrompt(kind: PackKind) = when (kind) {
        PackKind.BEHAVIOR -> """
You generate Minecraft Bedrock BEHAVIOR PACK content. Respond with ONE JSON object and nothing else:
{"name":"<short name>","description":"<one line>","files":[{"path":"<relative path>","content":"<file text>"}]}
Rules:
- Do NOT output manifest.json; the launcher generates it.
- Allowed paths: items/*.json, entities/*.json, recipes/*.json, loot_tables/**/*.json, scripts/main.js, texts/*.lang.
- Items use format_version "1.21.0" with "minecraft:item" and components.
- Gameplay logic goes in scripts/main.js using ONLY ES modules: import { world, system } from "@minecraft/server";
  e.g. world.afterEvents.itemUse.subscribe(e => { ... e.source.dimension.spawnEntity("minecraft:lightning_bolt", loc) }).
- Valid JSON only inside .json files. No placeholder text, no markdown."""
        PackKind.RESOURCE -> """
You generate Minecraft Bedrock RESOURCE PACK content. Respond with ONE JSON object and nothing else:
{"name":"<short name>","description":"<one line>","files":[{"path":"<relative path>","content":"<file text>"}]}
Rules:
- Do NOT output manifest.json; the launcher generates it.
- Allowed paths: ui/*.json, texts/*.lang, textures/*.json, items/*.json, attachables/*.json, sounds/*.json, particles/*.json.
- For UI themes, override ui/ JSON using valid Bedrock JSON-UI syntax (controls, "$variables", "color": [r,g,b] floats 0-1).
- Valid JSON only. No images (binary) — reference vanilla textures. No markdown."""
    }

    // ------------------------------------------------------------- 1. prompt -> LLM -> structured pack
    suspend fun generate(userPrompt: String, kind: PackKind): Result<GeneratedPack> = withContext(Dispatchers.IO) {
        runCatching {
            val body = buildJsonObject {
                put("model", config.model); put("max_tokens", 8000)
                put("system", systemPrompt(kind))
                putJsonArray("messages") { addJsonObject { put("role", "user"); put("content", userPrompt) } }
            }.toString().toRequestBody("application/json".toMediaType())

            val req = Request.Builder().url(config.endpoint)
                .header("x-api-key", config.apiKey).header("anthropic-version", "2023-06-01").post(body).build()
            val text = http.newCall(req).execute().use { r ->
                val s = r.body?.string().orEmpty()
                check(r.isSuccessful) { "LLM HTTP ${r.code}: ${s.take(200)}" }
                json.parseToJsonElement(s).jsonObject["content"]!!.jsonArray
                    .filter { it.jsonObject["type"]?.jsonPrimitive?.content == "text" }
                    .joinToString("") { it.jsonObject["text"]!!.jsonPrimitive.content }
            }
            build(parse(text), kind)
        }
    }

    // ------------------------------------------------------------- 2. robust parsing
    private fun parse(raw: String): LlmPack {
        val fenced = Regex("```(?:json)?\\s*([\\s\\S]*?)```").find(raw)?.groupValues?.get(1)
        val candidate = fenced ?: raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)
        return json.decodeFromString(candidate)
    }

    // ------------------------------------------------------------- 3. validate + sandbox + manifest
    private val allowedExt = setOf("json", "js", "lang")
    private fun build(p: LlmPack, kind: PackKind): GeneratedPack {
        require(p.files.isNotEmpty() && p.files.size <= 60) { "Bad file count" }
        require(p.files.sumOf { it.content.length } <= 512_000) { "Pack too large" }
        val out = linkedMapOf<String, ByteArray>()
        for (f in p.files) {
            val path = f.path.replace('\\', '/').trimStart('/')
            if (path.contains("..") || path.equals("manifest.json", true)) continue          // traversal / forged manifest
            if (path.substringAfterLast('.').lowercase() !in allowedExt) continue
            if (path.endsWith(".json")) json.parseToJsonElement(f.content)                    // throws on invalid JSON
            out[path] = f.content.toByteArray()
        }
        require(out.isNotEmpty()) { "Model returned no usable files" }

        val packId = UUID.randomUUID().toString(); val version = listOf(1, 0, 0)
        out["manifest.json"] = manifest(p, kind, packId, version, hasScript = "scripts/main.js" in out).toByteArray()
        return GeneratedPack(kind, p.name.ifBlank { "AI_Pack" }, packId, version, out)
    }

    private fun manifest(p: LlmPack, kind: PackKind, id: String, v: List<Int>, hasScript: Boolean) = buildJsonObject {
        put("format_version", 2)
        putJsonObject("header") {
            put("name", p.name); put("description", p.description.ifBlank { "Generated by Nebula AI" })
            put("uuid", id); putJsonArray("version") { v.forEach { add(it) } }
            put("min_engine_version", buildJsonArray { add(1); add(21); add(0) })
        }
        putJsonArray("modules") {
            addJsonObject {
                put("type", if (kind == PackKind.BEHAVIOR) "data" else "resources")
                put("uuid", UUID.randomUUID().toString()); putJsonArray("version") { v.forEach { add(it) } }
            }
            if (hasScript && kind == PackKind.BEHAVIOR) addJsonObject {
                put("type", "script"); put("language", "javascript"); put("entry", "scripts/main.js")
                put("uuid", UUID.randomUUID().toString()); putJsonArray("version") { v.forEach { add(it) } }
            }
        }
        if (hasScript && kind == PackKind.BEHAVIOR) putJsonArray("dependencies") {
            addJsonObject { put("module_name", "@minecraft/server"); put("version", config.scriptApiVersion) }
        }
    }.toString()

    // ------------------------------------------------------------- 4. package + inject
    fun toMcpack(pack: GeneratedPack, dest: File): File {
        ZipOutputStream(dest.outputStream().buffered()).use { z ->
            pack.files.forEach { (path, bytes) -> z.putNextEntry(ZipEntry(path)); z.write(bytes); z.closeEntry() }
        }
        return dest
    }

    /**
     * Installs into the active build's data dir: <gameData>/games/com.mojang/{behavior,resource}_packs/<name>.
     * If [worldDir] is given, also activates it by appending to world_{behavior,resource}_packs.json.
     * Script-API packs additionally need the "Beta APIs" experiment enabled on the world.
     */
    fun inject(pack: GeneratedPack, comMojangDir: File, worldDir: File? = null): File {
        val sub = if (pack.kind == PackKind.BEHAVIOR) "behavior_packs" else "resource_packs"
        val target = File(comMojangDir, "$sub/${pack.folderName}").apply { deleteRecursively(); mkdirs() }
        pack.files.forEach { (path, bytes) ->
            File(target, path).also { it.parentFile?.mkdirs() }.writeBytes(bytes)
        }
        worldDir?.let { w ->
            val f = File(w, if (pack.kind == PackKind.BEHAVIOR) "world_behavior_packs.json" else "world_resource_packs.json")
            val arr = if (f.exists()) json.parseToJsonElement(f.readText()).jsonArray else JsonArray(emptyList())
            val entry = buildJsonObject { put("pack_id", pack.packId); putJsonArray("version") { pack.version.forEach { add(it) } } }
            f.writeText(JsonArray(arr + entry).toString())
        }
        return target
    }
}
