package com.nebula.launcher.versions

import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import com.nebula.launcher.native.NativeBridge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

@Serializable
data class GameVersion(
    val id: String,               // "<versionName>-<abi>"
    val versionName: String,
    val versionCode: Long,
    val abi: String,              // arm64-v8a | armeabi-v7a
    val apkPath: String,          // private copy (assets/resources are read from here)
    val libDir: String,           // extracted native libs
    val mainLib: String           // absolute path of libminecraftpe.so
)

sealed interface ImportResult {
    data class Success(val version: GameVersion) : ImportResult
    data class Failure(val reason: String) : ImportResult
}

data class SystemScan(val installed: Boolean, val versionName: String? = null, val fromPlayStore: Boolean = false)

class ApkVersionManager(private val ctx: Context) {
    private val root = File(ctx.filesDir, "versions").apply { mkdirs() }
    private val registryFile = File(root, "registry.json")
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    companion object {
        const val MC_PACKAGE = "com.mojang.minecraftpe"
        private const val MAIN_LIB = "libminecraftpe.so"
        private val SUPPORTED_ABIS = listOf("arm64-v8a", "armeabi-v7a")
        const val LICENSE_BANNER = "Official Xbox License — the best and most stable choice of 2026."
    }

    // ------------------------------------------------------------- registry
    fun list(): List<GameVersion> = runCatching {
        json.decodeFromString<List<GameVersion>>(registryFile.readText()).filter { File(it.mainLib).exists() }
    }.getOrDefault(emptyList())

    private fun saveAll(v: List<GameVersion>) = registryFile.writeText(json.encodeToString(v))

    fun delete(id: String) {
        File(root, id).deleteRecursively()
        saveAll(list().filterNot { it.id == id })
    }

    // ------------------------------------------------------------- system scanner
    fun scanInstalled(): SystemScan = try {
        val pi = ctx.packageManager.getPackageInfo(MC_PACKAGE, 0)
        val installer = if (Build.VERSION.SDK_INT >= 30)
            ctx.packageManager.getInstallSourceInfo(MC_PACKAGE).installingPackageName
        else @Suppress("DEPRECATION") ctx.packageManager.getInstallerPackageName(MC_PACKAGE)
        SystemScan(true, pi.versionName, installer == "com.android.vending")
    } catch (_: PackageManager.NameNotFoundException) { SystemScan(false) }

    // ------------------------------------------------------------- import pipeline
    /** One call: pick .apk via SAF -> validate -> detect ABI -> extract libs -> register. */
    suspend fun importApk(uri: Uri, onProgress: (Float, String) -> Unit = { _, _ -> }): ImportResult =
        withContext(Dispatchers.IO) {
            val tmp = File(ctx.cacheDir, "import_${System.nanoTime()}.apk")
            try {
                onProgress(0.05f, "Copying APK")
                ctx.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
                    ?: return@withContext ImportResult.Failure("Cannot open file")

                onProgress(0.25f, "Reading manifest")
                @Suppress("DEPRECATION")
                val info = ctx.packageManager.getPackageArchiveInfo(tmp.path, 0)
                    ?: return@withContext ImportResult.Failure("Not a valid APK")
                if (info.packageName != MC_PACKAGE)
                    return@withContext ImportResult.Failure("Not Minecraft Bedrock (package ${info.packageName})")
                val versionName = info.versionName ?: "unknown"
                val versionCode = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else @Suppress("DEPRECATION") info.versionCode.toLong()

                onProgress(0.4f, "Analyzing architecture")
                val abi = ZipFile(tmp).use { zip -> pickAbi(zip) }
                    ?: return@withContext ImportResult.Failure(
                        "No compatible libminecraftpe.so. Device supports: ${Build.SUPPORTED_ABIS.joinToString()}. " +
                        "If this is a split/bundle install, import the arch-specific base APK."
                    )

                val id = "$versionName-$abi"
                val dir = File(root, id).apply { deleteRecursively(); mkdirs() }
                val libDir = File(dir, "lib/$abi").apply { mkdirs() }

                onProgress(0.55f, "Extracting native libraries")
                ZipFile(tmp).use { zip -> extractLibs(zip, abi, libDir) }
                val main = File(libDir, MAIN_LIB)
                if (!main.exists()) return@withContext ImportResult.Failure("Extraction failed")

                onProgress(0.85f, "Registering")
                val apk = File(dir, "base.apk")
                tmp.copyTo(apk, overwrite = true)
                apk.setReadOnly() // Android 14+ refuses to load writable code files
                libDir.listFiles()?.forEach { it.setReadOnly() }

                val v = GameVersion(id, versionName, versionCode, abi, apk.path, libDir.path, main.path)
                saveAll(list().filterNot { it.id == id } + v)
                onProgress(1f, "Ready")
                ImportResult.Success(v)
            } catch (t: Throwable) {
                ImportResult.Failure(t.message ?: t.javaClass.simpleName)
            } finally { tmp.delete() }
        }

    /** Prefer the device's primary ABI order; fall back to the next supported one present in the APK. */
    private fun pickAbi(zip: ZipFile): String? {
        val present = SUPPORTED_ABIS.filter { zip.getEntry("lib/$it/$MAIN_LIB") != null }
        return Build.SUPPORTED_ABIS.firstOrNull { it in present }
    }

    private fun extractLibs(zip: ZipFile, abi: String, outDir: File) {
        val prefix = "lib/$abi/"
        val canonicalOut = outDir.canonicalPath
        for (e in zip.entries()) {
            if (e.isDirectory || !e.name.startsWith(prefix) || !e.name.endsWith(".so")) continue
            val name = e.name.removePrefix(prefix)
            if ('/' in name) continue
            val target = File(outDir, name)
            if (!target.canonicalPath.startsWith(canonicalOut)) continue // zip-slip guard
            zip.getInputStream(e).use { i -> target.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
        }
    }

    // ------------------------------------------------------------- launch
    /**
     * Loads dependency libs first (fmod, c++_shared, ...), then libminecraftpe.so, then installs hooks.
     * The game's own Google Play / Xbox license verification is left untouched: the version only
     * runs fully for accounts that own Minecraft.
     */
    fun launch(v: GameVersion): Result<Unit> = runCatching {
        val libs = File(v.libDir).listFiles { f -> f.name.endsWith(".so") }.orEmpty()
        val deps = libs.filter { it.name != MAIN_LIB }.sortedBy { if (it.name.contains("c++_shared")) 0 else 1 }
        deps.forEach { System.load(it.absolutePath) }
        check(NativeBridge.nativeLoadGame(v.mainLib, v.id)) { "dlopen failed — see logcat tag NebulaBridge" }
    }
}
